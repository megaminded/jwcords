<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

$congregations = [
    'GRA' => 'GRA CONGREGATION',
    'STADIUM' => 'STADIUM CONGREGATION',
    'COLLEGE' => 'COLLEGE CONGREGATION',
    'NEW' => 'NEW LAYOUT CONGREGATION',
];
