<?php

// db jwfamilygps_main
// user 436364_jwfamilyg
// host mysql-jwfamilygps.alwaysdata.net
// password v@F6P8yeXjjQBTd
final class DBConnection
{
    private $host = "localhost";
    private $db = 'jw';
    private $user = 'root';
    private $password = 'protected';


    private function connect()
    {
        $connection = new mysqli($this->host, $this->user, $this->password, $this->db);
        if ($connection) {
            return $connection;
        } else {
            die("Unable to connect to database");
        }
    }

    public function save($data)
    {
        $congregation = $data['congregation'] ?? null;
        $name = $data['name'] ?? null;
        $phone = $data['phone'] ?? null;
        $publishers = $data['publishers'] ?? null;
        $longitude = $data['longitude'] ?? null;
        $latitude = $data['latitude'] ?? null;
        $time = date('Y-m-d h:i:s');
        $statement = "INSERT INTO coordinates (congregation, name, phone, publishers, longitude, latitude, create_time)";
        $statement .= "VALUES ('$congregation', '$name', '$phone', '$publishers', '$longitude', '$latitude', '$time')";

        $result = $this->connect()->query($statement);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function congregation($congregation)
    {
        $statement = "SELECT * FROM coordinates WHERE congregation = '$congregation'";
        $result = $this->connect()->query($statement);
        return $result;
    }
}
